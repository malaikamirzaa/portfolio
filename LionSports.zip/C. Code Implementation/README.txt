This folder contains the static HTML/CSS for our projects homepage (the main core page). 
To see it in phone scale, please go to the developer tool in Chrome and
select the scaling tool for phone size. 

Technologies Used
- **Frontend**: HTML, CSS, and Google Fonts for styling.
- **Backend**: Flask for dynamic rendering and data management.

How to Run
To run the app locally, execute the following command in your terminal:

bash
python3 app.py
Overview
This app allows users to browse and interact with information about upcoming sports events. Users can view detailed information for each event & predict scores. The app dynamically renders game details based on user selections.

- Game Details Page:
  - Displays detailed information about a selected game, including team names, logos, location, a map, and a description.
  - Dynamically rendered using Flask to ensure details match the selected game.
  - Includes a score prediction section where users can predict game scores.

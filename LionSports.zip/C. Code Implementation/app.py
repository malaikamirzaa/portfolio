from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Game Data
games = [
    {
        "id": 1,
        "sport": "WOMEN'S VOLLEYBALL",
        "teams": "Columbia vs. Cornell",
        "date": "Nov 1st, 2024",
        "time": "2:00pm",
        "location": "New York, NY",
        "venue": "Levian Gymnasium",
        "ticketed": False,
        "attendees": 360,
        "logos": ["columbia-logo.png", "cornell-logo.png"],
        "map": "volleyball-map.png",
        "user_guess": None  # Add user guess field
    },
    {
        "id": 2,
        "sport": "FOOTBALL",
        "teams": "Columbia vs. Dartmouth",
        "date": "Nov 1st, 2024",
        "time": "6:00pm",
        "location": "New York, NY",
        "venue": "Robert K. Kraft Field at Lawrence A. Wien Stadium",
        "ticketed": True,
        "attendees": 800,
        "logos": ["columbia-logo.png", "dartmouth-logo.png"],
        "map": "football-map.png",
        "user_guess": None
    },
    {
        "id": 3,
        "sport": "MEN'S SOCCER",
        "teams": "Columbia vs. Princeton",
        "date": "Nov 1st, 2024",
        "time": "5:00pm",
        "location": "New York, NY",
        "venue": "Rocco B. Commisso Soccer Stadium",
        "ticketed": False,
        "attendees": 200,
        "logos": ["columbia-logo.png", "princeton-logo.png"],
        "map": "soccer-map.png",
        "user_guess": None
    }
]

@app.route('/')
def home():
    return render_template("home.html", games=games)

@app.route('/details/<int:game_id>', methods=['GET', 'POST'])
def game_details(game_id):
    game = next((game for game in games if game["id"] == game_id), None)
    if game:
        if request.method == 'POST':
            # Get user's guess from the form
            columbia_score = request.form.get("columbia_score")
            opponent_score = request.form.get("opponent_score")
            # Store the guess in the game data
            game['user_guess'] = (columbia_score, opponent_score)
            return redirect(url_for('game_details', game_id=game_id))
        return render_template("gameDetails.html", game=game)
    return "Game not found", 404

@app.route('/join/<int:game_id>', methods=['POST'])
def join_game(game_id):
    game = next((game for game in games if game["id"] == game_id), None)
    if game:
        game['attendees'] += 1  # Increase the going count
    return redirect(url_for('game_details', game_id=game_id))

if __name__ == '__main__':
    app.run(debug=True)
